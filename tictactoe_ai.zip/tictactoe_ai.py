import tkinter as tk
from tkinter import messagebox


class TicTacToeAI:
    def __init__(self, master):  
        self.master = master
        self.master.title("Tic-Tac-Toe (Human vs Computer)")
        self.master.geometry("420x500")
        self.master.config(bg="#f0f8ff")

        self.player = "X"
        self.computer = "O"
        self.board = [["" for _ in range(3)] for _ in range(3)]

       
        self.score_player = 0
        self.score_computer = 0
        self.score_draw = 0

       
        self.label = tk.Label(master, text="Your Turn (X)", font=("Arial", 16, "bold"), bg="#f0f8ff")
        self.label.pack(pady=10)

        
        self.score_label = tk.Label(
            master,
            text=f"🏆 You: {self.score_player}   💻 Computer: {self.score_computer}   🤝 Draws: {self.score_draw}",
            font=("Arial", 13, "bold"), bg="#f0f8ff", fg="#333"
        )
        self.score_label.pack(pady=5)

        
        self.buttons = [[None for _ in range(3)] for _ in range(3)]
        frame = tk.Frame(master)
        frame.pack()

        for i in range(3):
            for j in range(3):
                btn = tk.Button(
                    frame, text="", font=("Arial", 24), width=5, height=2,
                    command=lambda row=i, col=j: self.human_move(row, col)
                )
                btn.grid(row=i, column=j)
                self.buttons[i][j] = btn

        
        self.reset_button = tk.Button(
            master, text="Restart 🔁", font=("Arial", 12, "bold"),
            bg="#4CAF50", fg="white", command=self.reset
        )
        self.reset_button.pack(pady=15)

    
    def human_move(self, row, col):
        if self.board[row][col] == "":
            self.board[row][col] = self.player
            self.buttons[row][col].config(text=self.player, state="disabled")

            if self.check_win(self.player):
                self.score_player += 1
                self.update_scoreboard()
                messagebox.showinfo("Game Over", "🎉 You Win!")
                self.disable_buttons()
                return
            elif self.is_draw():
                self.score_draw += 1
                self.update_scoreboard()
                messagebox.showinfo("Game Over", "🤝 It's a draw!")
                return

            self.label.config(text="Computer's Turn (O)")
            self.master.after(500, self.computer_move)

    
    def computer_move(self):
        best_score = float("-inf")
        best_move = None

        for i in range(3):
            for j in range(3):
                if self.board[i][j] == "":
                    self.board[i][j] = self.computer
                    score = self.minimax(self.board, 0, False)
                    self.board[i][j] = ""
                    if score > best_score:
                        best_score = score
                        best_move = (i, j)

        if best_move:
            i, j = best_move
            self.board[i][j] = self.computer
            self.buttons[i][j].config(text=self.computer, state="disabled")

        if self.check_win(self.computer):
            self.score_computer += 1
            self.update_scoreboard()
            messagebox.showinfo("Game Over", "💻 Computer Wins!")
            self.disable_buttons()
        elif self.is_draw():
            self.score_draw += 1
            self.update_scoreboard()
            messagebox.showinfo("Game Over", "🤝 It's a draw!")
        else:
            self.label.config(text="Your Turn (X)")

    def minimax(self, board, depth, is_maximizing):
        if self.check_win(self.computer, board):
            return 1
        elif self.check_win(self.player, board):
            return -1
        elif self.is_draw(board):
            return 0

        if is_maximizing:
            best_score = float("-inf")
            for i in range(3):
                for j in range(3):
                    if board[i][j] == "":
                        board[i][j] = self.computer
                        score = self.minimax(board, depth + 1, False)
                        board[i][j] = ""
                        best_score = max(score, best_score)
            return best_score
        else:
            best_score = float("inf")
            for i in range(3):
                for j in range(3):
                    if board[i][j] == "":
                        board[i][j] = self.player
                        score = self.minimax(board, depth + 1, True)
                        board[i][j] = ""
                        best_score = min(score, best_score)
            return best_score

    
    def check_win(self, player, board=None):
        if board is None:
            board = self.board
        for row in board:
            if all(cell == player for cell in row):
                return True
        for col in range(3):
            if all(board[row][col] == player for row in range(3)):
                return True
        if all(board[i][i] == player for i in range(3)) or all(board[i][2 - i] == player for i in range(3)):
            return True
        return False

    def is_draw(self, board=None):
        if board is None:
            board = self.board
        return all(cell != "" for row in board for cell in row)

    def disable_buttons(self):
        for row in self.buttons:
            for btn in row:
                btn.config(state="disabled")

    def reset(self):
        self.board = [["" for _ in range(3)] for _ in range(3)]
        self.label.config(text="Your Turn (X)")
        for row in self.buttons:
            for btn in row:
                btn.config(text="", state="normal")

    def update_scoreboard(self):
        self.score_label.config(
            text=f"🏆 You: {self.score_player}   💻 Computer: {self.score_computer}   🤝 Draws: {self.score_draw}"
        )


class WelcomePage:
    def __init__(self, master):  
        self.master = master
        self.master.title("Welcome to Tic-Tac-Toe")
        self.master.geometry("400x400")
        self.master.config(bg="#d7f0ff")

        tk.Label(
            master, text="🎮 Welcome to Tic-Tac-Toe 🎮",
            font=("Arial", 20, "bold"), bg="#d7f0ff", fg="#333"
        ).pack(pady=50)

        tk.Button(
            master, text="Start Game ▶", font=("Arial", 14, "bold"),
            bg="#4CAF50", fg="white", width=15, command=self.start_game
        ).pack(pady=20)

        tk.Button(
            master, text="Quit ❌", font=("Arial", 14, "bold"),
            bg="#f44336", fg="white", width=15, command=master.quit
        ).pack(pady=10)

    def start_game(self):
        self.master.destroy()
        main_game()


def main_game():
    root = tk.Tk()
    TicTacToeAI(root)
    root.mainloop()


if __name__ == "__main__": 
    root = tk.Tk()
    WelcomePage(root)
    root.mainloop()
